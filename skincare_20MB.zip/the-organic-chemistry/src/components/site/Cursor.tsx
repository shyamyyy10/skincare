import { useEffect, useRef } from "react";

/** A gold ring that trails the pointer and grows over interactive elements. Desktop only. */
export function Cursor() {
  const ring = useRef<HTMLDivElement>(null);
  const dot = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    document.body.classList.add("has-cursor");
    const pos = { x: -100, y: -100 };
    const lag = { x: -100, y: -100 };
    let hover = false;
    let raf = 0;
    const onMove = (e: PointerEvent) => {
      pos.x = e.clientX;
      pos.y = e.clientY;
      hover = !!(e.target as HTMLElement).closest("a, button, input, [data-cursor]");
    };
    const loop = () => {
      lag.x += (pos.x - lag.x) * 0.16;
      lag.y += (pos.y - lag.y) * 0.16;
      if (ring.current) ring.current.style.transform = `translate3d(${lag.x}px, ${lag.y}px, 0) translate(-50%, -50%) scale(${hover ? 1.9 : 1})`;
      if (dot.current) dot.current.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0) translate(-50%, -50%)`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("pointermove", onMove);
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      document.body.classList.remove("has-cursor");
    };
  }, []);

  return (
    <>
      <div
        ref={ring}
        className="pointer-events-none fixed left-0 top-0 z-[80] hidden h-10 w-10 rounded-full border border-primary/70 transition-[width,height] duration-300 [@media(pointer:fine)]:block"
      />
      <div
        ref={dot}
        className="pointer-events-none fixed left-0 top-0 z-[80] hidden h-1.5 w-1.5 rounded-full bg-primary [@media(pointer:fine)]:block"
      />
    </>
  );
}
