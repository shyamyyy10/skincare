import { useEffect, useState } from "react";
import { getLenis } from "@/lib/scroll-state";

/** Full-screen counter that waits for the 3D scene (or a timeout), then lifts away. */
export function Preloader({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    let sceneReady = false;
    const markReady = () => (sceneReady = true);
    window.addEventListener("scene-ready", markReady);
    const timeout = window.setTimeout(markReady, 5000);
    const start = performance.now();
    let raf = 0;
    let value = 0;
    const tick = () => {
      const elapsed = performance.now() - start;
      const cap = sceneReady ? 101 : 86;
      const target = Math.min(cap, (elapsed / 1800) * 101);
      value += (target - value) * 0.12;
      const shown = Math.min(100, Math.round(value));
      setCount(shown);
      if (shown >= 100) {
        setLeaving(true);
        onDone();
        window.setTimeout(() => setGone(true), 1400);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    getLenis()?.stop();
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(timeout);
      window.removeEventListener("scene-ready", markReady);
    };
  }, [onDone]);

  useEffect(() => {
    if (leaving) getLenis()?.start();
  }, [leaving]);

  if (gone) return null;
  return (
    <div
      className={`fixed inset-0 z-[70] flex flex-col justify-between bg-background p-6 transition-transform duration-[1300ms] ease-[cubic-bezier(0.76,0,0.24,1)] md:p-10 ${leaving ? "-translate-y-full" : ""}`}
    >
      <div className="flex justify-between eyebrow">
        <span>The Organic Chemistry</span>
        <span>Formulating</span>
      </div>
      <div className="flex items-end justify-between">
        <p className="max-w-[16ch] font-display text-2xl italic text-muted-foreground md:text-3xl">
          Measuring nature, gram by gram.
        </p>
        <span className="font-display-tight text-[28vw] text-gold-gradient tabular-nums md:text-[18vw]">
          {String(count).padStart(2, "0")}
        </span>
      </div>
      <div className="h-px w-full bg-border">
        <div className="h-px origin-left bg-primary" style={{ transform: `scaleX(${count / 100})` }} />
      </div>
    </div>
  );
}
