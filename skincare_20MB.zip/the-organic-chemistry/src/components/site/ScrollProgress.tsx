import { useEffect, useRef, useState } from "react";
import { onScrollFrame, scrollState } from "@/lib/scroll-state";

const NAMES = ["Intro", "Manifesto", "Serum", "Cream", "Cleanser", "Ingredients", "Ritual", "Begin"];

export function ScrollProgress() {
  const bar = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const off = onScrollFrame(() => {
      if (bar.current) bar.current.style.transform = `scaleY(${scrollState.progress})`;
      const i = Math.round(scrollState.s);
      setIdx((prev) => (prev === i ? prev : i));
    });
    return () => {
      off();
    };
  }, []);
  return (
    <div className="pointer-events-none fixed bottom-8 right-6 z-40 hidden items-end gap-4 md:flex">
      <div className="text-right">
        <div className="eyebrow text-primary">{NAMES[idx] ?? ""}</div>
        <div className="font-mono text-xs text-muted-foreground tabular-nums">
          {String(idx + 1).padStart(2, "0")} / {String(NAMES.length).padStart(2, "0")}
        </div>
      </div>
      <div className="h-24 w-px bg-border">
        <div ref={bar} className="h-full w-px origin-top bg-primary" style={{ transform: "scaleY(0)" }} />
      </div>
    </div>
  );
}
