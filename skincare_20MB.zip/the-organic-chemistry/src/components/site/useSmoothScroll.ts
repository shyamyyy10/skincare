import { useEffect } from "react";
import Lenis from "lenis";
import { emitScrollFrame, pointer, scrollState, setLenis } from "@/lib/scroll-state";

/** Lenis smooth scroll + section tracking + pointer tracking. Mount once on the page. */
export function useSmoothScroll() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const lenis = new Lenis({ lerp: reduce ? 1 : 0.085, wheelMultiplier: 0.9 });
    setLenis(lenis);

    let tops: { top: number; h: number }[] = [];
    const measure = () => {
      const els = Array.from(document.querySelectorAll<HTMLElement>("[data-section]"));
      tops = els.map((el) => ({ top: el.offsetTop, h: el.offsetHeight }));
      scrollState.sectionCount = tops.length;
    };

    const update = () => {
      const y = window.scrollY;
      const vh = window.innerHeight;
      const c = y + vh * 0.5;
      let s = 0;
      for (let i = 0; i < tops.length; i++) {
        const { top, h } = tops[i]!;
        if (c >= top && c < top + h) {
          s = i + (c - top) / h - 0.5;
          break;
        }
        if (i === tops.length - 1 && c >= top + h) s = i;
      }
      scrollState.s = Math.max(0, Math.min(tops.length - 1, s));
      const max = document.documentElement.scrollHeight - vh;
      scrollState.progress = max > 0 ? y / max : 0;
      scrollState.velocity = lenis.velocity;
      emitScrollFrame();
    };

    measure();
    update();
    lenis.on("scroll", update);
    const ro = new ResizeObserver(() => {
      measure();
      update();
    });
    ro.observe(document.body);

    let raf = 0;
    const loop = (t: number) => {
      lenis.raf(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const onMove = (e: PointerEvent) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = -((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("pointermove", onMove);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      ro.disconnect();
      lenis.destroy();
      setLenis(null);
    };
  }, []);
}
