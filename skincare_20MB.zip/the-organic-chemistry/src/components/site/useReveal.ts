import { useEffect } from "react";

/** Sets data-in="true" on every [data-reveal] element as it scrolls into view. */
export function useReveal(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    const els = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            (e.target as HTMLElement).dataset["in"] = "true";
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.2, rootMargin: "0px 0px -8% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [enabled]);
}
