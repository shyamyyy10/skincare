import * as THREE from "three";
import { C } from "./palette";

type LabelSpec = {
  bg: string | null;
  fg: string;
  accent: string;
  number: string;
  name: string[];
  formula: string;
  volume: string;
};

/** Draws a product label onto a canvas, centred horizontally (front of the product). */
function draw(ctx: CanvasRenderingContext2D, w: number, h: number, spec: LabelSpec, centreFrac: number) {
  ctx.clearRect(0, 0, w, h);
  if (spec.bg) {
    ctx.fillStyle = spec.bg;
    ctx.fillRect(0, 0, w, h);
  }
  const cx = w * 0.5;
  const pw = w * centreFrac; // printable width
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  ctx.fillStyle = spec.accent;
  ctx.font = `500 ${h * 0.055}px "JetBrains Mono", monospace`;
  ctx.fillText("THE ORGANIC CHEMISTRY", cx, h * 0.14);

  ctx.strokeStyle = spec.accent;
  ctx.lineWidth = Math.max(1, h * 0.004);
  ctx.beginPath();
  ctx.moveTo(cx - pw * 0.32, h * 0.23);
  ctx.lineTo(cx + pw * 0.32, h * 0.23);
  ctx.stroke();

  ctx.fillStyle = spec.fg;
  ctx.font = `300 ${h * 0.2}px "Fraunces", Georgia, serif`;
  ctx.fillText(spec.number, cx, h * 0.4);

  ctx.font = `400 ${h * 0.085}px "Fraunces", Georgia, serif`;
  spec.name.forEach((line, i) => ctx.fillText(line, cx, h * (0.6 + i * 0.1)));

  ctx.fillStyle = spec.accent;
  ctx.font = `400 ${h * 0.045}px "JetBrains Mono", monospace`;
  ctx.fillText(spec.formula, cx, h * 0.83);
  ctx.fillText(spec.volume, cx, h * 0.91);
}

export function makeLabel(spec: LabelSpec, w = 1024, h = 512, centreFrac = 1) {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  draw(ctx, w, h, spec, centreFrac);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  // Redraw once web fonts have arrived
  document.fonts?.ready.then(() => {
    draw(ctx, w, h, spec, centreFrac);
    tex.needsUpdate = true;
  });
  return tex;
}

export const labelSpecs = {
  serum: {
    bg: C.ink,
    fg: C.cream,
    accent: C.gold,
    number: "N°01",
    name: ["OpenMatcha", "Night Serum"],
    formula: "C18H24O · 1%",
    volume: "30 ML · 1.0 FL OZ",
  },
  cream: {
    bg: null,
    fg: C.gold,
    accent: C.gold,
    number: "N°02",
    name: ["Ceramide", "Cloud Creame"],
    formula: "CER-NP · 3%",
    volume: "50 ML · 1.7 FL OZ",
  },
  tube: {
    bg: C.cream,
    fg: C.ink,
    accent: C.goldDeep,
    number: "N°03",
    name: ["Enzyme", "Gel Cleanser & purifier"],
    formula: "PAPAIN · 0.5%",
    volume: "120 ML · 4.0 FL OZ",
  },
} satisfies Record<string, LabelSpec>;
