import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, Sparkles } from "@react-three/drei";
import { Suspense, useRef } from "react";
import * as THREE from "three";
import { pointer, scrollState } from "@/lib/scroll-state";
import { sample, tracks, type Pose } from "./choreography";
import { CleanserTube, CreamJar, SerumBottle } from "./Products";
import { HeroMolecule, MoleculeField } from "./Molecules";
import { C } from "./palette";

const damp = THREE.MathUtils.damp;
const FOLLOW = 5; // how fast objects chase their scroll pose
const SPIN = 0.25; // idle rotation speed (rad/s)

type Fit = { x: number; y: number; scale: number };

function applyPose(g: THREE.Group, p: Pose, fit: Fit, spin: number, dt: number) {
  g.position.x = damp(g.position.x, p.x * fit.x, FOLLOW, dt);
  g.position.y = damp(g.position.y, p.y + fit.y, FOLLOW, dt);
  g.position.z = damp(g.position.z, p.z, FOLLOW, dt);
  const s = damp(g.scale.x, p.sc * fit.scale, FOLLOW, dt);
  g.scale.setScalar(Math.max(s, 0.0001));
  g.visible = s > 0.01;
  g.rotation.y = damp(g.rotation.y, p.ry + spin, FOLLOW, dt);
  g.rotation.z = damp(g.rotation.z, p.rz, FOLLOW, dt);
}

function Stage({ onReady }: { onReady: () => void }) {
  const serum = useRef<THREE.Group>(null);
  const cream = useRef<THREE.Group>(null);
  const tube = useRef<THREE.Group>(null);
  const mol = useRef<THREE.Group>(null);
  const field = useRef<THREE.Group>(null);
  const rig = useRef<THREE.Group>(null);
  const spin = useRef(0);
  const ready = useRef(false);
  const { viewport, camera } = useThree();

  // The single stepper: reads scroll + pointer, drives every object.
  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const s = scrollState.s;
    spin.current += dt * (SPIN + Math.min(Math.abs(scrollState.velocity) * 0.02, 1.5));
    // Fit the layout to narrow screens: pull objects inward, shrink them, lift them above the text.
    const narrow = viewport.width < viewport.height;
    const fit: Fit = {
      x: THREE.MathUtils.clamp(viewport.width / 6, 0.3, 1),
      y: narrow ? (s > 6.5 ? -1.5 : 0.85) : 0, // final section: sit below the form
      scale: narrow ? THREE.MathUtils.clamp(viewport.width / 3, 0.55, 0.8) : 1,
    };

    if (serum.current) applyPose(serum.current, sample(tracks.serum, s), fit, spin.current, dt);
    if (cream.current) applyPose(cream.current, sample(tracks.cream, s), fit, spin.current * 0.6, dt);
    if (tube.current) applyPose(tube.current, sample(tracks.tube, s), fit, spin.current * 0.8, dt);
    if (mol.current) {
      applyPose(mol.current, sample(tracks.molecule, s), fit, spin.current * 0.5, dt);
      mol.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.4) * 0.4;
    }
    if (field.current) {
      field.current.position.y = damp(field.current.position.y, s * 0.9, 3, dt);
      field.current.rotation.y += dt * 0.02;
    }
    if (rig.current) {
      rig.current.rotation.y = damp(rig.current.rotation.y, pointer.x * 0.12, 3, dt);
      rig.current.rotation.x = damp(rig.current.rotation.x, -pointer.y * 0.08, 3, dt);
    }
    camera.position.x = damp(camera.position.x, pointer.x * 0.25, 2, dt);
    camera.position.y = damp(camera.position.y, pointer.y * 0.15, 2, dt);
    camera.lookAt(0, 0, 0);

    if (!ready.current) {
      ready.current = true;
      onReady();
    }
  });

  return (
    <group ref={rig}>
      <MoleculeField ref={field} />
      <SerumBottle ref={serum} />
      <CreamJar ref={cream} />
      <CleanserTube ref={tube} />
      <HeroMolecule ref={mol} />
    </group>
  );
}

export default function Experience({ onReady }: { onReady: () => void }) {
  const wrap = useRef<HTMLDivElement>(null);
  return (
    <div ref={wrap} className="pointer-events-none fixed inset-0 z-0" aria-hidden>
      <Canvas
        dpr={[1, 1.75]}
        camera={{ position: [0, 0, 6], fov: 35 }}
        gl={{ antialias: true, alpha: true, toneMapping: THREE.ACESFilmicToneMapping }}
      >
        <fog attach="fog" args={[C.ink, 6, 14]} />
        <ambientLight intensity={0.35} />
        <spotLight position={[4, 6, 5]} angle={0.35} penumbra={1} intensity={60} color={C.cream} />
        <pointLight position={[-4, -1, 2]} intensity={12} color={C.gold} />
        <Environment resolution={256}>
          <Lightformer intensity={3} position={[0, 5, -2]} scale={[10, 3, 1]} color={C.cream} />
          <Lightformer intensity={2.2} position={[-5, 1, 1]} rotation-y={Math.PI / 2} scale={[8, 2, 1]} color={C.gold} />
          <Lightformer intensity={1.6} position={[5, 0, 1]} rotation-y={-Math.PI / 2} scale={[8, 1, 1]} color={C.cream} />
          <Lightformer form="ring" intensity={2} position={[0, 0, 6]} scale={3} color={C.gold} />
        </Environment>
        <Sparkles count={90} scale={[12, 8, 6]} size={2.2} speed={0.25} opacity={0.6} color={C.gold} />
        <Suspense fallback={null}>
          <Stage
            onReady={() => {
              wrap.current?.setAttribute("data-scene-ready", "true");
              window.dispatchEvent(new Event("scene-ready"));
            }}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}
