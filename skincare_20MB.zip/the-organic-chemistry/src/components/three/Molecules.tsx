import { forwardRef, useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { C } from "./palette";

type Atom = { p: THREE.Vector3; r: number; gold: boolean };
type Mol = { atoms: Atom[]; bonds: [number, number][] };

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

/** Random-walk ball-and-stick molecules scattered through space (seeded, deterministic). */
function buildField(count: number, seed: number) {
  const r = rng(seed);
  const atoms: Atom[] = [];
  const bonds: [number, number][] = [];
  for (let m = 0; m < count; m++) {
    const centre = new THREE.Vector3((r() - 0.5) * 12, (r() - 0.5) * 9, -1.5 - r() * 5);
    const n = 3 + Math.floor(r() * 5);
    const start = atoms.length;
    atoms.push({ p: centre.clone(), r: 0.07 + r() * 0.05, gold: true });
    for (let i = 1; i < n; i++) {
      const parent = start + Math.floor(r() * i);
      const dir = new THREE.Vector3(r() - 0.5, r() - 0.5, r() - 0.5).normalize().multiplyScalar(0.32);
      atoms.push({ p: atoms[parent]!.p.clone().add(dir), r: 0.04 + r() * 0.05, gold: r() > 0.45 });
      bonds.push([parent, atoms.length - 1]);
    }
  }
  return { atoms, bonds } satisfies Mol;
}

const up = new THREE.Vector3(0, 1, 0);
function bondMatrix(a: THREE.Vector3, b: THREE.Vector3, radius: number) {
  const mid = a.clone().add(b).multiplyScalar(0.5);
  const dir = b.clone().sub(a);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(up, dir.normalize());
  return new THREE.Matrix4().compose(mid, q, new THREE.Vector3(radius, len, radius));
}

function InstancedMolecule({ mol, bondRadius = 0.012 }: { mol: Mol; bondRadius?: number }) {
  const goldRef = useRef<THREE.InstancedMesh>(null);
  const creamRef = useRef<THREE.InstancedMesh>(null);
  const bondRef = useRef<THREE.InstancedMesh>(null);
  const goldAtoms = mol.atoms.filter((a) => a.gold);
  const creamAtoms = mol.atoms.filter((a) => !a.gold);

  useLayoutEffect(() => {
    const m = new THREE.Matrix4();
    goldAtoms.forEach((a, i) => goldRef.current!.setMatrixAt(i, m.compose(a.p, new THREE.Quaternion(), new THREE.Vector3(a.r, a.r, a.r))));
    creamAtoms.forEach((a, i) => creamRef.current!.setMatrixAt(i, m.compose(a.p, new THREE.Quaternion(), new THREE.Vector3(a.r, a.r, a.r))));
    mol.bonds.forEach(([i, j], k) => bondRef.current!.setMatrixAt(k, bondMatrix(mol.atoms[i]!.p, mol.atoms[j]!.p, bondRadius)));
    [goldRef, creamRef, bondRef].forEach((r) => (r.current!.instanceMatrix.needsUpdate = true));
  }, [mol, goldAtoms, creamAtoms, bondRadius]);

  return (
    <>
      <instancedMesh ref={goldRef} args={[undefined, undefined, goldAtoms.length]}>
        <sphereGeometry args={[1, 32, 24]} />
        <meshPhysicalMaterial color={C.gold} metalness={1} roughness={0.25} clearcoat={0.5} />
      </instancedMesh>
      <instancedMesh ref={creamRef} args={[undefined, undefined, creamAtoms.length]}>
        <sphereGeometry args={[1, 32, 24]} />
        <meshPhysicalMaterial color={C.cream} roughness={0.3} clearcoat={1} />
      </instancedMesh>
      <instancedMesh ref={bondRef} args={[undefined, undefined, mol.bonds.length]}>
        <cylinderGeometry args={[1, 1, 1, 12]} />
        <meshStandardMaterial color={C.gold} metalness={0.8} roughness={0.35} />
      </instancedMesh>
    </>
  );
}

export const MoleculeField = forwardRef<THREE.Group>(function MoleculeField(_, ref) {
  const mol = useMemo(() => buildField(22, 7), []);
  return (
    <group ref={ref}>
      <InstancedMolecule mol={mol} />
    </group>
  );
});

/** A stylised aromatic ring with side chains — the "hero" molecule of the ingredients section. */
function buildHeroMolecule(): Mol {
  const atoms: Atom[] = [];
  const bonds: [number, number][] = [];
  const R = 0.62;
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    atoms.push({ p: new THREE.Vector3(Math.cos(a) * R, Math.sin(a) * R, 0), r: 0.15, gold: i % 2 === 0 });
    bonds.push([i, (i + 1) % 6]);
  }
  const chains: [number, number, number, boolean][] = [
    [0, 1.05, 0.25, false], [2, 1.0, -0.3, true], [4, 1.0, 0.35, false], [5, 1.1, -0.2, true],
  ];
  for (const [base, dist, z, gold] of chains) {
    const p = atoms[base]!.p.clone().normalize().multiplyScalar(R + dist * 0.55).setZ(z);
    atoms.push({ p, r: 0.12, gold });
    bonds.push([base, atoms.length - 1]);
    const p2 = p.clone().multiplyScalar(1.38).setZ(-z);
    atoms.push({ p: p2, r: 0.085, gold: !gold });
    bonds.push([atoms.length - 2, atoms.length - 1]);
  }
  return { atoms, bonds };
}

export const HeroMolecule = forwardRef<THREE.Group>(function HeroMolecule(_, ref) {
  const mol = useMemo(() => buildHeroMolecule(), []);
  return (
    <group ref={ref}>
      <InstancedMolecule mol={mol} bondRadius={0.035} />
    </group>
  );
});
