// Scene colours mirror the CSS design tokens (Midnight luxe).
export const C = {
  ink: "#0d0d0f",
  umber: "#1f1c1a",
  gold: "#c9a46a",
  goldDeep: "#9c7a45",
  cream: "#f5efe6",
  amber: "#9a5520",
  amberLiquid: "#d8953a",
  rubber: "#141212",
};
