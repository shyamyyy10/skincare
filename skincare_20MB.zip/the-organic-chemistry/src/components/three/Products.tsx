import { forwardRef, useMemo } from "react";
import * as THREE from "three";
import { C } from "./palette";
import { labelSpecs, makeLabel } from "./labels";

const lathe = (pts: [number, number][], seg = 96) =>
  new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r, y)), seg);

function useGold() {
  return useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: C.gold,
        metalness: 1,
        roughness: 0.22,
        clearcoat: 0.6,
        clearcoatRoughness: 0.2,
      }),
    [],
  );
}

/** N°01 — amber glass dropper bottle */
export const SerumBottle = forwardRef<THREE.Group>(function SerumBottle(_, ref) {
  const gold = useGold();
  const { body, liquid, label } = useMemo(() => {
    const body = lathe([
      [0, 0], [0.34, 0], [0.4, 0.03], [0.42, 0.1], [0.42, 0.95], [0.4, 1.03],
      [0.3, 1.11], [0.17, 1.16], [0.16, 1.24], [0, 1.24],
    ]);
    const liquid = lathe([
      [0, 0.04], [0.37, 0.04], [0.385, 0.1], [0.385, 0.78], [0, 0.78],
    ]);
    const L = Math.PI * 0.95;
    const label = new THREE.CylinderGeometry(0.426, 0.426, 0.52, 96, 1, true, -L / 2, L);
    return { body, liquid, label };
  }, []);
  const labelTex = useMemo(() => makeLabel(labelSpecs.serum, 1024, 560), []);

  return (
    <group ref={ref}>
      <group position={[0, -0.78, 0]}>
        <mesh geometry={body}>
          <meshPhysicalMaterial
            color={C.amber}
            transmission={1}
            thickness={0.6}
            roughness={0.06}
            ior={1.5}
            attenuationColor={C.amber}
            attenuationDistance={0.9}
            clearcoat={1}
            transparent
          />
        </mesh>
        <mesh geometry={liquid}>
          <meshPhysicalMaterial color={C.amberLiquid} roughness={0.15} transmission={0.5} thickness={0.4} emissive={C.amber} emissiveIntensity={0.15} />
        </mesh>
        <mesh geometry={label} position={[0, 0.52, 0]}>
          <meshStandardMaterial map={labelTex} roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* collar */}
        <mesh position={[0, 1.34, 0]} material={gold}>
          <cylinderGeometry args={[0.2, 0.2, 0.22, 64]} />
        </mesh>
        <mesh position={[0, 1.235, 0]} material={gold}>
          <torusGeometry args={[0.2, 0.018, 16, 64]} />
        </mesh>
        {/* rubber bulb */}
        <mesh position={[0, 1.55, 0]}>
          <cylinderGeometry args={[0.13, 0.15, 0.22, 48]} />
          <meshStandardMaterial color={C.rubber} roughness={0.55} />
        </mesh>
        <mesh position={[0, 1.68, 0]} scale={[1, 1.25, 1]}>
          <sphereGeometry args={[0.13, 48, 32]} />
          <meshStandardMaterial color={C.rubber} roughness={0.55} />
        </mesh>
      </group>
    </group>
  );
});

/** N°02 — dark glass jar with gold lid */
export const CreamJar = forwardRef<THREE.Group>(function CreamJar(_, ref) {
  const gold = useGold();
  const { body, lid, label } = useMemo(() => {
    const body = lathe([
      [0, 0], [0.62, 0], [0.69, 0.03], [0.72, 0.1], [0.72, 0.56], [0.68, 0.6], [0.6, 0.62], [0, 0.62],
    ]);
    const lid = lathe([
      [0, 0.62], [0.7, 0.62], [0.735, 0.65], [0.74, 0.88], [0.72, 0.93], [0.66, 0.95], [0, 0.96],
    ]);
    const L = Math.PI * 0.8;
    const label = new THREE.CylinderGeometry(0.724, 0.724, 0.42, 96, 1, true, -L / 2, L);
    return { body, lid, label };
  }, []);
  const labelTex = useMemo(() => makeLabel(labelSpecs.cream, 1024, 380), []);

  return (
    <group ref={ref}>
      <group position={[0, -0.48, 0]}>
        <mesh geometry={body}>
          <meshPhysicalMaterial color={C.umber} roughness={0.18} metalness={0.1} clearcoat={1} clearcoatRoughness={0.05} sheen={0.4} sheenColor={C.gold} />
        </mesh>
        <mesh geometry={label} position={[0, 0.33, 0]}>
          <meshStandardMaterial map={labelTex} transparent roughness={0.4} metalness={0.6} side={THREE.DoubleSide} />
        </mesh>
        <mesh geometry={lid} material={gold} />
      </group>
    </group>
  );
});

/** N°03 — cream squeeze tube standing on its gold cap */
export const CleanserTube = forwardRef<THREE.Group>(function CleanserTube(_, ref) {
  const gold = useGold();
  const tube = useMemo(() => {
    const h = 1.75;
    const g = new THREE.CylinderGeometry(0.36, 0.36, h, 96, 48, false, Math.PI, Math.PI * 2);
    const pos = g.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      const t = (y + h / 2) / h; // 0 bottom → 1 top
      const k = Math.pow(t, 1.6);
      pos.setX(i, pos.getX(i) * (1 + 0.3 * k));
      pos.setZ(i, pos.getZ(i) * (1 - 0.93 * k));
    }
    g.computeVertexNormals();
    return g;
  }, []);
  const labelTex = useMemo(() => makeLabel(labelSpecs.tube, 2048, 900, 0.45), []);

  return (
    <group ref={ref}>
      <group position={[0, -0.1, 0]}>
        <mesh geometry={tube} position={[0, 0.3, 0]}>
          <meshPhysicalMaterial map={labelTex} roughness={0.42} clearcoat={0.6} clearcoatRoughness={0.3} />
        </mesh>
        {/* crimp */}
        <mesh position={[0, 1.2, 0]} material={gold}>
          <boxGeometry args={[0.95, 0.07, 0.05]} />
        </mesh>
        {/* cap */}
        <mesh position={[0, -0.72, 0]} material={gold}>
          <cylinderGeometry args={[0.37, 0.39, 0.36, 64]} />
        </mesh>
      </group>
    </group>
  );
});
