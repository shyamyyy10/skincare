/**
 * Scroll choreography: keyframes keyed by section position `s`
 * (s = i when section i is centred in the viewport). Pure TS, no three.js.
 */
export type Pose = { x: number; y: number; z: number; sc: number; ry: number; rz: number };
export type Key = Pose & { s: number };
export type Track = Key[];

const P = (s: number, x: number, y: number, sc: number, ry = 0, rz = 0, z = 0): Key => ({
  s, x, y, z, sc, ry, rz,
});
/** A plateau: the pose holds for a little while around section i */
const hold = (i: number, x: number, y: number, sc: number, ry = 0, rz = 0, w = 0.18): Key[] => [
  P(i - w, x, y, sc, ry, rz),
  P(i + w, x, y, sc, ry, rz),
];

const smooth = (t: number) => t * t * (3 - 2 * t);

export function sample(track: Track, s: number): Pose {
  const first = track[0]!;
  const last = track[track.length - 1]!;
  if (s <= first.s) return first;
  if (s >= last.s) return last;
  for (let i = 0; i < track.length - 1; i++) {
    const a = track[i]!;
    const b = track[i + 1]!;
    if (s >= a.s && s <= b.s) {
      const t = smooth((s - a.s) / Math.max(b.s - a.s, 1e-6));
      return {
        x: a.x + (b.x - a.x) * t,
        y: a.y + (b.y - a.y) * t,
        z: a.z + (b.z - a.z) * t,
        sc: a.sc + (b.sc - a.sc) * t,
        ry: a.ry + (b.ry - a.ry) * t,
        rz: a.rz + (b.rz - a.rz) * t,
      };
    }
  }
  return last;
}

// Sections: 0 hero · 1 manifesto · 2 serum · 3 cream · 4 cleanser · 5 ingredients · 6 ritual · 7 cta
export const tracks: Record<"serum" | "cream" | "tube" | "molecule", Track> = {
  serum: [
    ...hold(0, 0, -0.05, 1.15, 0, 0, 0.1),
    ...hold(1, 1.6, 0.05, 1, 0.6, -0.12),
    ...hold(2, 1.5, -0.05, 1.12, Math.PI * 2, 0),
    P(2.8, 0.6, 2.8, 0.8, Math.PI * 2.5, 0.3),
    P(5.4, -1.9, -3.2, 0.5, 0, 0),
    ...hold(6, 0, -0.55, 0.62, 0, 0),
    ...hold(7, -2.35, 0.05, 0.85, 0, 0.1),
  ],
  cream: [
    P(0, -1.5, -3.4, 0.8),
    P(2.2, -1.5, -3.4, 0.8),
    ...hold(3, -1.5, -0.15, 1.15, Math.PI * 2, 0),
    P(3.8, -0.6, 2.8, 0.8, Math.PI * 2.5, -0.3),
    P(5.4, 1.9, -3.2, 0.5),
    ...hold(6, 1.9, -0.62, 0.62),
    ...hold(7, 2.5, -0.8, 0.62),
  ],
  tube: [
    P(0, 1.5, -3.4, 0.8),
    P(3.2, 1.5, -3.4, 0.8),
    ...hold(4, 1.5, -0.05, 1.05, Math.PI * 2, -0.18),
    P(4.8, 0.6, 2.9, 0.8, Math.PI * 2.5, 0.3),
    P(5.4, -1.9, -3.2, 0.5),
    ...hold(6, -1.9, -0.5, 0.6, 0, 0),
    ...hold(7, 2.05, 0.3, 0.72, 0, -0.15),
  ],
  molecule: [
    P(0, 1.4, -0.1, 0),
    P(4.4, 1.4, -0.1, 0),
    ...hold(5, 1.35, -0.05, 1, Math.PI, 0, 0.22),
    P(5.85, 1.35, 0.4, 0, Math.PI * 1.6),
  ],
};
