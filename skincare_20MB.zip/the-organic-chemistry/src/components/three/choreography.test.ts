import { describe, expect, it } from "vitest";
import { sample, tracks } from "./choreography";

describe("scroll choreography", () => {
  it("features each product in its own section", () => {
    expect(sample(tracks.serum, 2).sc).toBeGreaterThan(1);
    expect(sample(tracks.cream, 3).sc).toBeGreaterThan(1);
    expect(sample(tracks.tube, 4).sc).toBeGreaterThan(1);
  });
  it("keeps other products off-screen while one is featured", () => {
    expect(Math.abs(sample(tracks.cream, 2).y)).toBeGreaterThan(2.5);
    expect(Math.abs(sample(tracks.serum, 3.5).y)).toBeGreaterThan(1.5);
    expect(sample(tracks.molecule, 3).sc).toBe(0);
  });
});

describe("ritual line-up", () => {
  it("orders products cleanse → treat → nourish from left to right", () => {
    const x = (t: keyof typeof tracks) => sample(tracks[t], 6).x;
    expect(x("tube")).toBeLessThan(x("serum"));
    expect(x("serum")).toBeLessThan(x("cream"));
  });
});
