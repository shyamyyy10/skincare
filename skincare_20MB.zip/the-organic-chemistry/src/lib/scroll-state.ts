import type Lenis from "lenis";

/**
 * Shared, mutable scroll + pointer state. Written by the smooth-scroll loop,
 * read every frame by the 3D scene. Never stored in React state.
 */
export const scrollState = {
  /** Section position: 0 = first section centred, 1 = second section centred ... */
  s: 0,
  /** Whole-page progress 0..1 */
  progress: 0,
  velocity: 0,
  sectionCount: 1,
};

export const pointer = { x: 0, y: 0 };

type Listener = () => void;
const listeners = new Set<Listener>();
export function onScrollFrame(fn: Listener) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
export function emitScrollFrame() {
  listeners.forEach((fn) => fn());
}

let lenis: Lenis | null = null;
export const setLenis = (l: Lenis | null) => {
  lenis = l;
};
export const getLenis = () => lenis;

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  if (lenis) lenis.scrollTo(el, { duration: 1.8 });
  else el.scrollIntoView({ behavior: "smooth" });
}
