import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useCallback, useEffect, useState, type ReactNode } from "react";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Preloader } from "@/components/site/Preloader";
import { Cursor } from "@/components/site/Cursor";
import { ScrollProgress } from "@/components/site/ScrollProgress";
import { useSmoothScroll } from "@/components/site/useSmoothScroll";
import { useReveal } from "@/components/site/useReveal";
import { scrollToId } from "@/lib/scroll-state";

const Experience = lazy(() => import("@/components/three/Experience"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "The Organic Chemistry — Organic actives, measured precisely" },
      {
        name: "description",
        content:
          "Small-batch skincare where plant-derived actives meet a chemist's precision. Discover the Bakuchiol serum, Ceramide cream and Enzyme cleanser.",
      },
      { property: "og:title", content: "The Organic Chemistry — Skin, distilled." },
      {
        property: "og:description",
        content:
          "Plant-derived actives, printed percentages, small batches. A three-step skincare ritual.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

/* ---------- small building blocks ---------- */

function Lines({
  lines,
  className = "",
  delay = 0,
}: {
  lines: ReactNode[];
  className?: string;
  delay?: number;
}) {
  return (
    <span data-reveal className={className}>
      {lines.map((l, i) => (
        <span key={i} className="line-mask" style={{ ["--d" as string]: `${delay + i * 110}ms` }}>
          <span>{l}</span>
        </span>
      ))}
    </span>
  );
}

function Fade({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <div data-reveal className={`reveal ${className}`} style={{ ["--d" as string]: `${delay}ms` }}>
      {children}
    </div>
  );
}

function Section({
  id,
  children,
  className = "",
}: {
  id: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      id={id}
      data-section
      className={`relative min-h-screen w-full px-6 md:px-12 ${className}`}
    >
      {children}
    </section>
  );
}

/* ---------- content ---------- */

const products = [
  {
    id: "serum",
    no: "N°01",
    name: ["OpenMatcha", "Night Serum"],
    formula: "C₁₈H₂₄O · 1% Bakuchiol",
    copy: "A plant-born alternative to retinol from the seeds of Psoralea corylifolia. Smooths texture overnight without the sting.",
    notes: ["Bakuchiol 1%", "Squalane", "Rosehip oil"],
    side: "left" as const,
  },
  {
    id: "cream",
    no: "N°02",
    name: ["Ceramide", "Cloud Creame"],
    formula: "CER-NP · 3% Ceramide complex",
    copy: "A whipped barrier cream that rebuilds the skin's lipid wall, so moisture stays where it belongs — in.",
    notes: ["Ceramides 3%", "Shea butter", "Niacinamide"],
    side: "right" as const,
  },
  {
    id: "cleanser",
    no: "N°03",
    name: ["Enzyme", "Gel Cleanser & purifier"],
    formula: "Papain · 0.5% Fruit enzyme",
    copy: "Papaya enzymes dissolve the day gently. A low-foam gel that leaves skin clean, never tight.",
    notes: ["Papain 0.5%", "Aloe", "Oat amino acids"],
    side: "left" as const,
  },
];

const elements = [
  { sym: "Bk", n: "01", name: "Bakuchiol", origin: "Babchi seed" },
  { sym: "Sq", n: "02", name: "Squalane", origin: "Olive" },
  { sym: "Cr", n: "03", name: "Ceramides", origin: "Plant lipids" },
  { sym: "Ni", n: "04", name: "Niacinamide", origin: "Vitamin B3" },
  { sym: "Ha", n: "05", name: "Hyaluronic", origin: "Fermented" },
  { sym: "Pa", n: "06", name: "Papain", origin: "Papaya" },
];

const ritual = [
  {
    step: "01",
    title: "Cleanse",
    product: "Enzyme Gel Cleanser",
    copy: "Massage onto damp skin for sixty seconds. Rinse warm.",
  },
  {
    step: "02",
    title: "Treat",
    product: "Bakuchiol Night Serum",
    copy: "Three drops, pressed in. Evenings, every evening.",
  },
  {
    step: "03",
    title: "Nourish",
    product: "Ceramide Cloud Cream",
    copy: "A pearl-sized amount to seal everything in.",
  },
];

function Nav() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 flex items-center justify-between px-6 py-5 mix-blend-difference md:px-12">
      <button onClick={() => scrollToId("intro")} className="text-left leading-none">
        <span className="block font-display text-lg italic tracking-tight">The Organic</span>
        <span className="eyebrow block text-foreground">Chemistry</span>
      </button>
      <nav className="hidden items-center gap-10 text-sm md:flex">
        {(
          [
            ["serum", "Products"],
            ["ingredients", "Ingredients"],
            ["ritual", "Ritual"],
          ] as const
        ).map(([id, label]) => (
          <button key={id} onClick={() => scrollToId(id)} className="link-line">
            {label}
          </button>
        ))}
      </nav>
      <Button variant="line" size="sm" onClick={() => scrollToId("begin")} className="px-5">
        Join waitlist
      </Button>
    </header>
  );
}

function Index() {
  const [mounted, setMounted] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [email, setEmail] = useState("");
  useEffect(() => setMounted(true), []);
  useSmoothScroll();
  useReveal(loaded);
  const onDone = useCallback(() => setLoaded(true), []);

  return (
    <div className="grain relative bg-stage">
      {mounted && (
        <Suspense fallback={null}>
          <Experience onReady={() => undefined} />
        </Suspense>
      )}
      {mounted && <Preloader onDone={onDone} />}
      <Cursor />
      <Nav />
      <ScrollProgress />

      <main className="relative z-10">
        {/* 0 — Hero */}
        <Section id="intro" className="flex flex-col justify-between pb-10 pt-32">
          <div className="flex justify-between">
            <Fade className="eyebrow">Est. 2026 — Small-batch skincare lab</Fade>
            <Fade className="eyebrow hidden md:block" delay={150}>
              N°01 — N°03
            </Fade>
          </div>
          <h1 className="font-display-tight pointer-events-none text-center text-[19vw] md:text-[13.5vw]">
            <Lines
              lines={[
                "Skin,",
                <em key="d" className="text-gold-gradient">
                  distilled.
                </em>,
              ]}
              delay={100}
            />
          </h1>
          <div className="flex items-end justify-between gap-6">
            <Fade className="max-w-xs text-sm leading-relaxed text-muted-foreground" delay={300}>
              Organic actives, measured with a chemist's precision. Formulas that respect your
              skin's own biology.
            </Fade>
            <Fade delay={450}>
              <button
                onClick={() => scrollToId("manifesto")}
                className="eyebrow flex items-center gap-3 text-foreground"
              >
                Scroll to explore
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-border animate-float-slow">
                  <ArrowDown className="h-4 w-4" />
                </span>
              </button>
            </Fade>
          </div>
        </Section>

        {/* 1 — Manifesto */}
        <Section id="manifesto" className="flex flex-col justify-center py-32">
          <div className="max-w-3xl">
            <Fade className="eyebrow mb-8 text-primary">( Our philosophy )</Fade>
            <p className="font-display text-4xl font-light leading-[1.1] tracking-tight md:text-6xl">
              <Lines
                lines={[
                  "We believe the best",
                  <>formulas are the ones</>,
                  <>
                    you can <em className="text-primary">read.</em>
                  </>,
                ]}
              />
            </p>
            <div className="mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:grid-cols-3">
              {[
                ["Plant-derived", "Every active starts in a seed, a fruit or a leaf."],
                ["Printed percentages", "The dose is on the label. Always."],
                ["Fragrance-free", "Nothing added just to smell nice."],
              ].map(([t, c], i) => (
                <Fade key={t} delay={i * 120} className="border-t border-border pt-4">
                  <div className="mb-2 text-sm font-semibold">{t}</div>
                  <div className="text-sm text-muted-foreground">{c}</div>
                </Fade>
              ))}
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-10 overflow-hidden whitespace-nowrap border-y border-border py-4">
            <div className="flex w-max animate-marquee font-display text-3xl italic text-muted-foreground md:text-5xl">
              {Array.from({ length: 2 }).map((_, k) => (
                <span key={k} className="flex">
                  {["Clean", "Conscious", "Clinical", "Botanical", "Measured", "Honest"].map(
                    (w) => (
                      <span key={w} className="flex items-center px-8">
                        {w}
                        <span className="ml-16 text-primary">✦</span>
                      </span>
                    ),
                  )}
                </span>
              ))}
            </div>
          </div>
        </Section>

        {/* 2–4 — Products */}
        {products.map((p, i) => (
          <Section
            key={p.id}
            id={p.id}
            className="flex items-end pb-16 pt-32 md:items-center md:py-32"
          >
            <div className={`w-full max-w-xl ${p.side === "right" ? "ml-auto" : ""}`}>
              <div className="mb-10 flex items-center gap-4">
                <Fade className="font-mono text-sm text-primary">{p.no}</Fade>
                <Fade className="h-px flex-1 bg-border" delay={100}>
                  <span />
                </Fade>
                <Fade className="eyebrow" delay={200}>
                  {String(i + 1).padStart(2, "0")} / 03
                </Fade>
              </div>
              <h2 className="font-display-tight text-6xl md:text-8xl">
                <Lines
                  lines={[
                    p.name[0],
                    <em key="n" className="text-gold-gradient">
                      {p.name[1]}
                    </em>,
                  ]}
                />
              </h2>
              <Fade
                className="mt-6 font-mono text-xs tracking-widest text-muted-foreground"
                delay={200}
              >
                {p.formula}
              </Fade>
              <Fade
                className="mt-8 max-w-md text-lg leading-relaxed text-muted-foreground"
                delay={300}
              >
                {p.copy}
              </Fade>
              <Fade className="mt-8 flex flex-wrap gap-2" delay={400}>
                {p.notes.map((n) => (
                  <span key={n} className="rounded-full border border-border px-4 py-1.5 text-xs">
                    {n}
                  </span>
                ))}
              </Fade>
              <Fade className="mt-10" delay={500}>
                <Button variant="gold" size="xl" onClick={() => scrollToId("begin")}>
                  Reserve {p.no} <ArrowUpRight />
                </Button>
              </Fade>
            </div>
          </Section>
        ))}

        {/* 5 — Ingredients */}
        <Section id="ingredients" className="flex items-center py-32">
          <div className="w-full max-w-xl">
            <Fade className="eyebrow mb-6 text-primary">( The formulary )</Fade>
            <h2 className="font-display-tight text-5xl md:text-7xl">
              <Lines
                lines={[
                  "A periodic table",
                  <em key="g" className="text-gold-gradient">
                    of good skin.
                  </em>,
                ]}
              />
            </h2>
            <Fade className="mt-6 max-w-md text-muted-foreground" delay={200}>
              Six hero actives, each sourced from a plant and dosed at the level the research
              supports.
            </Fade>
            <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {elements.map((e, i) => (
                <Fade key={e.sym} delay={i * 80}>
                  <div className="element-tile aspect-square rounded-md p-4" data-cursor>
                    <div className="flex justify-between font-mono text-[10px] text-muted-foreground">
                      <span>{e.n}</span>
                      <span>{e.origin}</span>
                    </div>
                    <div className="mt-3 font-display text-5xl font-light text-primary md:text-6xl">
                      {e.sym}
                    </div>
                    <div className="mt-1 text-xs">{e.name}</div>
                  </div>
                </Fade>
              ))}
            </div>
          </div>
        </Section>

        {/* 6 — Ritual */}
        <Section id="ritual" className="flex flex-col pb-10 pt-32">
          <div className="text-center">
            <Fade className="eyebrow mb-6 text-primary">( The ritual )</Fade>
            <h2 className="font-display-tight text-5xl md:text-7xl">
              <Lines
                lines={[
                  <>
                    Three steps{" "}
                    <em key="r" className="text-gold-gradient">
                      Nightly.
                    </em>
                  </>,
                ]}
              />
            </h2>
          </div>
          <div className="mt-16 grid flex-1 grid-cols-1 gap-10 md:grid-cols-3">
            {ritual.map((r, i) => (
              <Fade key={r.step} delay={i * 150} className="text-center md:px-6">
                <div className="font-mono text-xs text-primary">{r.step}</div>
                <div className="mt-3 font-display text-4xl italic">{r.title}</div>
                <div className="eyebrow mt-3">{r.product}</div>
                <p className="mx-auto mt-4 max-w-[26ch] text-sm text-muted-foreground">{r.copy}</p>
              </Fade>
            ))}
          </div>
        </Section>

        {/* 7 — Begin / CTA */}
        <Section id="begin" className="flex flex-col justify-between pb-8 pt-32">
          <div className="text-center">
            <h2 className="font-display-tight text-[16vw] md:text-[10vw]">
              <Lines
                lines={[
                  "Begin your",
                  <em key="b" className="text-gold-gradient">
                    ritual.
                  </em>,
                ]}
              />
            </h2>
            <Fade className="mx-auto mt-6 max-w-md text-muted-foreground" delay={200}>
              The first batch is small. Join the waitlist to reserve yours before it ships.
            </Fade>
            <Fade delay={300}>
              <form
                className="mx-auto mt-10 flex max-w-md items-center gap-2 rounded-full border border-border bg-card/60 p-1.5 backdrop-blur"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!/^\S+@\S+\.\S+$/.test(email)) {
                    toast.error("Please enter a valid email address.");
                    return;
                  }
                  toast.success("You're on the list. We'll write when the batch is ready.");
                  setEmail("");
                }}
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  aria-label="Email address"
                  className="flex-1 bg-transparent px-5 text-sm outline-none placeholder:text-muted-foreground"
                />
                <Button type="submit" variant="gold" className="h-11 px-6">
                  Join
                </Button>
              </form>
            </Fade>
          </div>
          <footer
            className="
              mt-24
              flex
              flex-col
              items-center
              justify-between
              gap-4
              border-t
              border-border
              pt-6
              text-xs
              text-muted-foreground
              md:flex-row
              md:pr-28
            "
          >
            <span>© 2026 The Organic Chemistry</span>
            <span className="font-mono tracking-widest">
              PLANT-DERIVED · SMALL-BATCH · FRAGRANCE-FREE
            </span>
            <button onClick={() => scrollToId("intro")} className="link-line">
              Back to top ↑
            </button>
          </footer>
        </Section>
      </main>
    </div>
  );
}
